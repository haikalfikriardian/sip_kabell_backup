package com.example.sip_kabell_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
